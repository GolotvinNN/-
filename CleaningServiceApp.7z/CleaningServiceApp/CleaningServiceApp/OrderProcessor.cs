﻿using System.Collections.Generic;
using System.Linq;

namespace CleaningServiceApp
{
    public class OrderProcessor
    {
        public decimal CalculateOrderCost(CleaningType cleaningType, decimal area, bool hasAdditionalServices)
        {
            decimal baseCost = cleaningType == CleaningType.Регулярная ? 100 : 200;
            decimal areaCost = area * 50;
            decimal additionalServicesCost = hasAdditionalServices ? 50 : 0;

            return baseCost + areaCost + additionalServicesCost;
        }

        public Order AssignOrderToWorker(List<Order> orders, Worker worker)
        {
            var availableOrders = orders.Where(o => o.Status == OrderStatus.Новый).OrderBy(o => o.Priority);
            var selectedOrder = availableOrders.FirstOrDefault();

            if (selectedOrder != null)
            {
                selectedOrder.AssignedWorker = worker;
                selectedOrder.Status = OrderStatus.Выполняется;
                worker.AssignedOrders.Add(selectedOrder);

                return selectedOrder; 
            }

            return null; 
        }
    }

}


