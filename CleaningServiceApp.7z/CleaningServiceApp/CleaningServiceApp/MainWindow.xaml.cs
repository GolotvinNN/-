﻿using CleaningServiceApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace CleaningServiceApp
{
    public partial class MainWindow : Window
    {
        public List<Order> Orders { get; set; }
        public List<Order> AssignedOrders { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Orders = new List<Order>();
            AssignedOrders = new List<Order>();

            OrdersDataGrid.ItemsSource = Orders;
            AssignedOrdersDataGrid.ItemsSource = AssignedOrders;

       
            CleaningTypeComboBox.Items.Add("Регулярная уборка");
            CleaningTypeComboBox.Items.Add("Генеральная уборка");
        }

        private void RegisterOrder_Click(object sender, RoutedEventArgs e)
        {
            string clientName = ClientNameTextBox.Text;
            string cleaningType = (string)CleaningTypeComboBox.SelectedItem;
            string areaText = AreaTextBox.Text;
            bool additionalServices = AdditionalServicesCheckBox.IsChecked == true;

            if (string.IsNullOrEmpty(clientName) || string.IsNullOrEmpty(cleaningType) || string.IsNullOrEmpty(areaText))
            {
                MessageBox.Show("Пожалуйста, заполните все поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!double.TryParse(areaText, out double area))
            {
                MessageBox.Show("Введите корректное значение площади", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

         
            decimal cost = CalculateCost(area, cleaningType, additionalServices);

            Order newOrder = new Order
            {
                ClientName = clientName,
                CleaningType = cleaningType == "Регулярная уборка" ? CleaningType.Регулярная : CleaningType.Генеральная,
                Area = (decimal)area,
                TotalCost = cost,
                Status = OrderStatus.Новый
            };

            Orders.Add(newOrder);
            OrdersDataGrid.Items.Refresh();
            MessageBox.Show("Заявка успешно создана", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private decimal CalculateCost(double area, string cleaningType, bool additionalServices)
        {
            decimal baseRate = cleaningType == "Регулярная уборка" ? 100 : 200; 
            decimal areaCost = (decimal)(area * 50);
            decimal additionalServicesCost = additionalServices ? 50 : 0;

            return baseRate + areaCost + additionalServicesCost;
        }

        private void AssignOrder_Click(object sender, RoutedEventArgs e)
        {
            string workerName = WorkerNameTextBox.Text;

            if (string.IsNullOrEmpty(workerName))
            {
                MessageBox.Show("Введите имя исполнителя", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var selectedOrder = (Order)OrdersDataGrid.SelectedItem;
            if (selectedOrder == null)
            {
                MessageBox.Show("Выберите заявку для назначения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

          
            Worker worker = new Worker { Name = workerName };

            OrderProcessor processor = new OrderProcessor();
            var orderAssigned = processor.AssignOrderToWorker(Orders, worker);

            if (orderAssigned != null)
            {
               
                AssignedOrders.Add(orderAssigned);

                
                OrdersDataGrid.Items.Refresh();
                AssignedOrdersDataGrid.Items.Refresh();

                MessageBox.Show($"Заявка успешно назначена исполнителю {worker.Name}", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


    }
}




