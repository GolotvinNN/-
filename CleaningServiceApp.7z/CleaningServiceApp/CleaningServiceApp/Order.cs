﻿using System;

namespace CleaningServiceApp
{
    public enum OrderStatus { Новый, Выполняется, Завершен }
    public enum CleaningType { Регулярная, Генеральная }

    public class Order
    {
        public int Id { get; set; }
        public string ClientName { get; set; }
        public CleaningType CleaningType { get; set; }
        public decimal Area { get; set; }
        public bool HasAdditionalServices { get; set; }
        public decimal TotalCost { get; set; }
        public OrderStatus Status { get; set; }
        public Worker AssignedWorker { get; set; } 
        public int Priority { get; set; } 

        
        public string AssignedWorkerName => AssignedWorker?.Name ?? "Не назначен";
    }

}
