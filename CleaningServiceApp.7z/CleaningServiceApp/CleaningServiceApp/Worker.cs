﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleaningServiceApp
{
    public class Worker
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<Order> AssignedOrders { get; set; } = new List<Order>();
    }
}
